import 'package:flutter/material.dart';

void main() => runApp(const JayakApp());

const brand = Color(0xFF16A36A);
const ink = Color(0xFF202A33);

class JayakApp extends StatelessWidget {
  const JayakApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'جايك',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: brand, primary: brand),
        scaffoldBackgroundColor: const Color(0xFFF7F9F8),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: HomeShell()),
    );
  }
}

class Product {
  final String name;
  final String store;
  final String category;
  final int price;
  final IconData icon;
  final Color color;
  const Product(this.name, this.store, this.category, this.price, this.icon, this.color);
}

const products = <Product>[
  Product('وجبة برغر كلاسيك', 'مطعم جايك برغر', 'مطاعم', 6000, Icons.lunch_dining, Color(0xFFFFE7D6)),
  Product('دجاج مشوي', 'مطعم التنور', 'مطاعم', 9000, Icons.restaurant, Color(0xFFFFE2DF)),
  Product('سلة خضار يومية', 'أسواق المدينة', 'سوبر ماركت', 5000, Icons.eco, Color(0xFFE0F3E6)),
  Product('حليب طازج', 'ماركت النخيل', 'سوبر ماركت', 2000, Icons.local_drink, Color(0xFFE1EEFF)),
  Product('مستلزمات عناية', 'صيدلية الشفاء', 'صيدليات', 7500, Icons.medical_services, Color(0xFFEDE5FF)),
  Product('فيتامينات عامة', 'صيدلية الحياة', 'صيدليات', 12000, Icons.health_and_safety, Color(0xFFE0F4F1)),
];

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  String category = 'الكل';
  String search = '';
  final Map<Product, int> cart = {};

  int get cartCount => cart.values.fold(0, (a, b) => a + b);
  int get total => cart.entries.fold(0, (sum, e) => sum + e.key.price * e.value);

  void add(Product p) => setState(() => cart.update(p, (v) => v + 1, ifAbsent: () => 1));
  void changeQty(Product p, int delta) => setState(() {
    final next = (cart[p] ?? 0) + delta;
    if (next <= 0) { cart.remove(p); } else { cart[p] = next; }
  });

  @override
  Widget build(BuildContext context) {
    final pages = [homePage(), cartPage(), const ProfilePage()];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: [
          const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: const Icon(Icons.shopping_bag_outlined), selectedIcon: const Icon(Icons.shopping_bag), label: 'السلة${cartCount > 0 ? ' ($cartCount)' : ''}'),
          const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }

  Widget homePage() {
    final visible = products.where((p) => (category == 'الكل' || p.category == category) && ('${p.name} ${p.store}'.contains(search))).toList();
    return CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 46, height: 46, decoration: BoxDecoration(color: brand.withOpacity(.12), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.delivery_dining, color: brand, size: 29)),
            const SizedBox(width: 10),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('جايك', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: ink)), Text('كل طلباتك توصلك لباب البيت', style: TextStyle(color: Colors.black54, fontSize: 12))])),
            IconButton(onPressed: () => setState(() => tab = 1), icon: Badge(isLabelVisible: cartCount > 0, label: Text('$cartCount'), child: const Icon(Icons.shopping_bag_outlined, size: 27))),
          ]),
          const SizedBox(height: 18),
          Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(20)), child: const Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('اطلب… والباقي علينا', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold)), SizedBox(height: 5), Text('مطاعم وأسواق وصيدليات في مكان واحد', style: TextStyle(color: Colors.white, fontSize: 12))])), Icon(Icons.delivery_dining, color: Colors.white, size: 55)])),
          const SizedBox(height: 16),
          TextField(onChanged: (v) => setState(() => search = v.trim()), decoration: InputDecoration(hintText: 'ابحث عن مطعم أو منتج…', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none), contentPadding: const EdgeInsets.symmetric(vertical: 4))),
          const SizedBox(height: 17),
          const Text('تسوّق حسب القسم', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: ink)),
          const SizedBox(height: 10),
          SizedBox(height: 94, child: ListView(scrollDirection: Axis.horizontal, children: [
            categoryTile('الكل', Icons.apps, const Color(0xFFE4F3EB)),
            categoryTile('مطاعم', Icons.restaurant, const Color(0xFFFFE9DD)),
            categoryTile('سوبر ماركت', Icons.shopping_basket, const Color(0xFFE4F0FF)),
            categoryTile('صيدليات', Icons.local_pharmacy, const Color(0xFFECE6FF)),
          ])),
          const SizedBox(height: 16),
          Row(children: [const Expanded(child: Text('منتجات مقترحة', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: ink))), Text('${visible.length} منتج', style: const TextStyle(color: Colors.black45, fontSize: 12))]),
          const SizedBox(height: 10),
        ]),
      )),
      SliverPadding(padding: const EdgeInsets.fromLTRB(18, 0, 18, 20), sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
        delegate: SliverChildBuilderDelegate((context, i) => productCard(visible[i]), childCount: visible.length),
      )),
    ]);
  }

  Widget categoryTile(String label, IconData icon, Color bg) => GestureDetector(onTap: () => setState(() => category = label), child: Container(width: 82, margin: const EdgeInsets.only(left: 9), decoration: BoxDecoration(color: category == label ? brand.withOpacity(.12) : Colors.white, borderRadius: BorderRadius.circular(15), border: Border.all(color: category == label ? brand : Colors.transparent)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [CircleAvatar(backgroundColor: bg, child: Icon(icon, color: ink)), const SizedBox(height: 7), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600))])));

  Widget productCard(Product p) => Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 9, offset: const Offset(0, 3))]), child: Padding(padding: const EdgeInsets.all(11), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(color: p.color, borderRadius: BorderRadius.circular(13)), child: Icon(p.icon, size: 54, color: ink.withOpacity(.75)))), const SizedBox(height: 9), Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)), Text(p.store, maxLines: 1, style: const TextStyle(color: Colors.black45, fontSize: 10)), const Spacer(), Row(children: [Expanded(child: Text('${p.price} د.ع', style: const TextStyle(color: brand, fontWeight: FontWeight.w900, fontSize: 13))), InkWell(onTap: () => add(p), borderRadius: BorderRadius.circular(10), child: Container(padding: const EdgeInsets.all(7), decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.add, color: Colors.white, size: 19)))])])));

  Widget cartPage() => Column(children: [const Padding(padding: EdgeInsets.all(18), child: Align(alignment: Alignment.centerRight, child: Text('سلة مشترياتك', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)))), Expanded(child: cart.isEmpty ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.shopping_bag_outlined, size: 65, color: Colors.black26), SizedBox(height: 12), Text('السلة فارغة', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), Text('أضف منتجاتك المفضلة واطلبها الآن', style: TextStyle(color: Colors.black45))])) : ListView(children: cart.entries.map((e) => ListTile(leading: CircleAvatar(backgroundColor: e.key.color, child: Icon(e.key.icon, color: ink)), title: Text(e.key.name), subtitle: Text('${e.key.price} د.ع'), trailing: Row(mainAxisSize: MainAxisSize.min, children: [IconButton(onPressed: () => changeQty(e.key, -1), icon: const Icon(Icons.remove_circle_outline)), Text('${e.value}'), IconButton(onPressed: () => changeQty(e.key, 1), icon: const Icon(Icons.add_circle_outline))]))).toList())), if (cart.isNotEmpty) Container(padding: const EdgeInsets.all(18), color: Colors.white, child: Column(children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('المجموع', style: TextStyle(fontWeight: FontWeight.bold)), Text('$total د.ع', style: const TextStyle(color: brand, fontWeight: FontWeight.w900, fontSize: 18))]), const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton(onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('الطلب التجريبي'), content: const Text('تم تجهيز واجهة السلة. سنضيف العنوان وتأكيد الطلب وربط المندوب في المرحلة التالية.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))])), child: const Text('متابعة إتمام الطلب')))]))]);
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('حسابي', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 18), const CircleAvatar(radius: 38, backgroundColor: Color(0xFFE4F3EB), child: Icon(Icons.person, size: 42, color: brand)), const SizedBox(height: 12), const Center(child: Text('مرحباً بك في جايك', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), const SizedBox(height: 20), const Card(child: ListTile(leading: Icon(Icons.location_on_outlined), title: Text('عناويني'), subtitle: Text('إضافة عنوان التوصيل'))), const Card(child: ListTile(leading: Icon(Icons.receipt_long_outlined), title: Text('طلباتي'), subtitle: Text('متابعة الطلبات السابقة'))), const Card(child: ListTile(leading: Icon(Icons.support_agent), title: Text('الدعم والمساعدة'))), const SizedBox(height: 12), const Center(child: Text('جايك | النسخة التجريبية الأولى', style: TextStyle(color: Colors.black38, fontSize: 11)))]);
}
